pip install bs4
cd
cd ..
cd usr/etc
rm bash.bashrc
cd $HOME/BadshaH/Revert
mv bash.bashrc $PREFIC/etc
python $HOME/BadshaH/Revert/Thanks.py
